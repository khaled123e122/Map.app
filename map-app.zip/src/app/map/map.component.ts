import { Component, ElementRef, ViewChild } from "@angular/core";
import { MapService } from "./map.service";
import { HttpClientModule } from "@angular/common/http";
import { NgIf } from "@angular/common";

@Component({
  selector: "app-map",
  standalone: true,
  imports: [HttpClientModule, NgIf],
  providers: [MapService],
  templateUrl: "./map.component.html",
  styleUrl: "./map.component.css",
})
export class MapComponent {
  svgContent: string = "";

  constructor(public mapService: MapService) {}

  @ViewChild("map") mapElement!: ElementRef;

  ngAfterViewInit() {
    this.getSVGData();
  }

  // load the svg from the file and get its content
  getSVGData() {
    this.mapService.getSVGData().subscribe((svg) => {
      this.svgContent = svg;
      this.renderSVG();
    });
  }

  renderSVG() {
    this.mapElement.nativeElement.innerHTML = this.svgContent;
    this.attachEventListeners();
  }

  // add event-listeners to the `path` elements in the SVG
  attachEventListeners() {
    const svg = this.mapElement.nativeElement;
    const paths = svg.querySelectorAll("path");

    paths.forEach((path: SVGPathElement) => {
      // click event to fetch and show the country info
      path.addEventListener("click", (event: any) => {
        path.style.fill = "blue";
        const countryCode = event.target.getAttribute("id");
        this.mapService.updateCountry(countryCode);
      });

      // methods to add/remove background color on mouse hover
      path.addEventListener("mouseover", (event: any) => {
        event.target.style.fill = "red";
      });

      path.addEventListener("mouseleave", (event: any) => {
        event.target.style.fill = "#000";
      });
    });
  }
}
