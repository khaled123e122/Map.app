import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: "root",
})
export class MapService {
  countryInfo = {
    name: "",
    capital: "",
    incomeLevel: "",
    region: "",
    latitude: "",
    longitude: "",
  };
  constructor(private http: HttpClient) {}

  getSVGData() {
    return this.http.get("assets/world.svg", { responseType: "text" });
  }

  // method to make the http request
  // Using the Worldbank API as per the requirements
  getCountryInfoFromCode(countryCode: string) {
    return this.http.get(
      `https://api.worldbank.org/V2/country/${countryCode}?format=json`
    );
  }

  // method to get the response and update the local variable
  updateCountry(countryCode: string) {
    this.getCountryInfoFromCode(countryCode).subscribe((data: any) => {
      // if data exists, set the countryInfo
      if (data[1][0]) {
        // according to the requirements, six properties should be shown to the user
        const obj = data[1][0];
        this.countryInfo = {
          name: obj.name,
          capital: obj.capitalCity,
          incomeLevel: obj.incomeLevel.value,
          region: obj.region.value,
          latitude: obj.latitude,
          longitude: obj.longitude,
        };
      }
    });
  }
}
